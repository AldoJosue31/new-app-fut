# Bracket — Más allá del amateur

Campaña investigada a partir del código y las pantallas de Bracket. El usuario aprobó producir **solo VIDEO A**, y después pidió una versión más inmersiva, con mayor detalle de animación y voz narradora. La producción responde a esa corrección.

## VIDEO A

60 segundos · 1080 × 1920 · 9:16 · 60 FPS · español.

- [Master con narración, música y efectos](final/bracket-a-60s.mp4).
- [Master sin audio](final/bracket-a-60s_silent.mp4).
- [Vista previa HTML interactiva](video-a/index.html).
- [Subtítulos opcionales SRT](final/bracket-a-es.srt).
- [Storyboard de producción y locución](03-video-a-storyboard.md).
- [Cómo editar y reproducir el render](video-a/LEEME.md).
- [Recursos y licencias](ASSETS.md), [control de calidad](QA.md) e [informe de sonido](sound-a/SOUND.md).

El HTML incorpora el logo original y las fuentes. El audio del preview procede del MP4 final; mantener la estructura de carpetas. Con `node video-a/serve.mjs`, abrir `http://127.0.0.1:4188/video-a/index.html`. El parámetro `?captions` activa subtítulos de apoyo en la vista previa.

## Investigación conservada

1. [Producto, arquitectura, roles y evidencia](01-investigacion.md).
2. [Dirección creativa inicial](02-direccion-creativa.md), conservada como antecedente; el storyboard A recoge la revisión solicitada.
3. [Propuesta VIDEO B](04-video-b-storyboard.md), pendiente de aprobación de producción.
4. [Propuesta opcional VIDEO C](05-video-c-opcional.md), pendiente de aprobación de producción.
5. [Plan original de producción](06-produccion-y-calidad.md); los resultados efectivos se registran en QA.md.

La investigación aprobó 159 pruebas de lógica/contratos, 14 pruebas existentes de navegador y 4 comprobaciones editoriales con datos sintéticos. Registros en `research/`. No se guardaron datos en una competición real ni se invocó el proveedor remoto del escaneo.

La interfaz está recreada desde componentes reales; Copa de Barrio, sus equipos y resultados son ejemplos ficticios. El escaneo lleva el aviso «Demostración ilustrativa · lectura resumida» y conserva la revisión y confirmación humanas. La descarga de una imagen y el acceso público a la tabla son acciones distintas. No se añadieron precios, estadísticas comerciales, testimonios o funciones sin verificar.

Todo el trabajo de campaña está dentro de esta carpeta. El código funcional de la aplicación permanece sin cambios.
