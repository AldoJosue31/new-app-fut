# Recursos utilizados — VIDEO A

## Identidad y diseño

| Recurso | Procedencia | Uso |
|---|---|---|
| `assets/original/logo_app.png` | Copia binaria de `public/logo_app.png` del proyecto Bracket | Inicio, navegación contextual y cierre. El PNG original se incrusta en el HTML y se anima con máscara/escala uniforme |
| Poppins 400, 600, 700 WOFF2 | Archivos autoalojados originales de `public/fonts/poppins` | Todos los textos de la animación; fuentes incrustadas en el HTML |
| `assets/original/OFL.txt` | Licencia SIL Open Font License original | Acompaña las fuentes |
| Paleta | `src/styles/themes.jsx` | Azul `#1CB0F6`, fondo `#EDF3FB`, superficies blancas y bordes azul claro; estados de éxito derivados del tema |
| Interfaz vectorial | Código de Bracket y capturas de investigación | Recreación simplificada por encuadre. Los controles, etiquetas, navegación y orden de acciones proceden de componentes reales |
| Equipos y cédula | Datos y gráficos originales de la campaña | Halcones, Leones, Norte, Sur y sus monogramas; documento ficticio. No corresponden a clientes o personas reales |

SHA-256 del logo: `8fdfd91bbc70c43ce0b3fd13683c8ec5563a913d4c70e5bb411620b776179217`.

La frase «Más allá del amateur» fue indicada por el usuario. «Antes del primer gol», los títulos de capítulo y la composición publicitaria son copy y dirección originales de esta campaña.

## Sonido

Música: «Techno Fights» de Alejandro Magaña (A. M.), Mixkit #171. Efectos: kit CC0 de Freesound y grabación de teclado Mixkit #1392. No se sintetizó música ni se añadieron osciladores como efectos. Consultar [verificación de licencias](assets/licenses/LICENCE-REVIEW.md), [créditos](sound-a/CREDITS.txt) y [mediciones de sonido](sound-a/SOUND.md).

Locución: voz sintética española de catálogo `em_alex`, generada localmente con [Kokoro-82M](https://huggingface.co/hexgrad/Kokoro-82M), modelo Apache 2.0. Motor kokoro-onnx 0.6.1, MIT. Clips y texto en `assets/voice/`; los pesos del modelo no se redistribuyen. Se aplica filtro, compresión suave y normalización antes de la mezcla; la música se atenúa 10 dB bajo la voz. No se clona una identidad real.

Los archivos Mixkit originales no se incluyen en la distribución de fuentes. La vista previa reproduce el audio del MP4 final entregado. Para rehacer la mezcla se deben adquirir los archivos desde sus fuentes con la licencia vigente; el programa de descarga los guarda únicamente en el entorno local.

## Herramientas y procedimiento

- `explainer-default`: guion, composición HTML/Canvas determinista y renderer con motion blur temporal. Fuentes originales y algoritmo de animación en `video-a/`.
- `sound-effects`: análisis de beats, contraste con graves, selección de cues, mezcla, normalización y pruebas de sincronía del MP4.
- Playwright 1.61.1 / Chromium: render del lienzo y comprobaciones de preview.
- FFmpeg 6.1.1 y ffprobe 4.0.2 encontrados en dependencias locales previas; se copiaron a `.tools` sin cambiar las dependencias de la aplicación. Los binarios y el entorno Python no se incluyen en el paquete de fuentes.
- Python 3.11.3 y las dependencias de análisis listadas en `sound-a/requirements.txt`.

Adaptaciones al renderer de la skill: rutas Windows, comprobación del encoder y captura JPEG directa del canvas a calidad 95. La captura directa se contrastó contra una captura del navegador: no hubo diferencia de píxeles en la comprobación PNG. Se conserva el muestreo a cuatro subfotogramas por frame, la media exposición de obturador y la combinación temporal/codificación del renderer original.

Adaptaciones a la pasada de sonido: scratch local en lugar de `/tmp`, codificación UTF-8, rutas portables del manifest, entrada de narración y ducking por sus duraciones. Se conservan el análisis de beats, la normalización y las pruebas del MP4.

La revisión inmersiva se compone en `video-a/ui-scenes.js` y `video-a/immersive.js`, compilados por `build.mjs`. Una malla proyecta los paneles en perspectiva durante entradas y salidas; los planos vuelven a una posición frontal para leer las acciones. Cancha, cámara, conexiones y viajes de equipos se dibujan desde código, sin material deportivo de terceros. La primera versión tranquila queda como histórico local y se excluye del paquete final.

## Qué representa la demostración

La competición y los resultados son ficticios. Sus puntos se comprobaron con el cálculo real `buildTorneoStandingsSnapshot` de Bracket; datos en `assets/demo-data/competition.json`.

El escaneo se representa como reconstrucción ilustrativa, con la espera resumida y revisión antes de guardar. No se atribuye al proveedor remoto una precisión o velocidad medida. La exportación y la consulta pública son salidas distintas; no se muestra publicación automática en una red social.

La cédula dibujada muestra un extracto ilustrativo de datos, no un documento expedido por una liga real. No hay material de jugadores, grabaciones de personas ni video base con transcripción; no se aplicaron SAM 2 ni motion-broll.
