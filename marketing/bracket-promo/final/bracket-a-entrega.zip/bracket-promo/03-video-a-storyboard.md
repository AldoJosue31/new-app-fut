# VIDEO A — storyboard de producción, revisión inmersiva

**Más allá del amateur.** Un organizador transforma la preparación de una liga en una jornada con resultados que sus equipos pueden consultar. La emoción procede del recorrido completo y de su pasión por la competición.

El usuario aprobó A y luego pidió mayor inmersión, detalle de animación y voz narradora. Se conserva el motor de `explainer-default`: HTML determinista, interfaz reconstruida, interacción coherente, cámaras por escena y render con cuatro muestras temporales por fotograma. Su dirección visual se adapta a esa petición: entorno deportivo oscuro, profundidad y títulos de mayor presencia. `sound-effects` realiza una pasada independiente con archivos grabados, beats medidos, voz prioritaria y normalización. B y C no forman parte de esta producción.

## Montaje

| Tiempo | Historia y texto | Imagen, movimiento e interacción | Sonido |
|---|---|---|---|
| 0–4,65 | **ANTES DEL / PRIMER GOL.** | Logo original pequeño. Tipografía por líneas. Un trazo azul conecta Equipos, Reglas y Jornadas sobre una cancha en perspectiva; nodos discretos avanzan por el espacio. | Voz: «Antes del primer gol, hay una liga que poner en marcha». Entrada musical y whoosh breve a 0,40. |
| 4,15–7,2 | **Bracket · Tu liga empieza aquí.** | Acercamiento al PNG oficial con escala uniforme; disolución hacia el primer espacio de interfaz. | Locución de marca a 4,90. Impacto de presentación a 4,65. |
| 7–10,5 | **TU LIGA. / TUS REGLAS.** | Configuración real en un plano que entra con perspectiva. Se escribe Copa de Barrio, se muestra fecha y límites, y la cámara acompaña el guardado. | Voz: definir torneo y reglas. Teclado grabado 7,55; click 8,90. |
| 10,5–15,3 | Mismo capítulo | Incorporación de Halcones, Leones, Norte y Sur. Filas y contador responden. El encuadre desciende hacia Siguiente: Sorteo. | La narración completa la incorporación de equipos. Clicks 11,40, 12,25 y 14,00. |
| 15,3–20,5 | **CADA CRUCE. / EN SU LUGAR.** | Los nombres viajan desde la lista hacia los cruces. Se construyen las conexiones y tarjetas del fixture. La cámara se aproxima al sorteo y acompaña Confirmar Fixture. | Voz: «Dale forma al calendario…». Whoosh 15,30; aparición 17,45; confirmación 19,386. |
| 20,5–27,3 | Jornada organizada | Cambio de hora a 11:30, transición de lista a grilla y confirmación de Jornada 1. Acercamiento al horario; desplazamiento hacia confirmar y apertura del encuadre para leer el resultado. | Voz: ajustar horarios, confirmar jornada y dar lugar a cada cruce. Clicks 22,10, 24,30 y 25,65. |
| 27,3–29 | **DEL PAPEL / AL MARCADOR.** | Definir Resultado entra con perspectiva; el foco se mueve hacia Escanear cédula. | La narración introduce lo que sucede después del partido. Whoosh 27,30. |
| 29–33,4 | Cargar y leer | Cédula ficticia, pulsación y progreso de lectura. Aviso visible: **Demostración ilustrativa · lectura resumida**. | Voz sobre cargar y revisar. Clicks 29,80 y 31,40; respuesta 33,40. |
| 33,4–39,3 | Revisar, aplicar y confirmar | Cédula y datos interpretados se conectan con un trazo editorial. Se revisan 2–1 y jugadores, se aplica, se guarda y se confirma. El resultado guardado se sostiene antes de salir. | Voz: «…confirma el marcador. Tú tienes la última palabra». Clicks 34,95, 36,40 y 37,65; respuesta 38,10. |
| 39,3–46 | **EL RESULTADO / SE VE.** | La tabla se organiza y Halcones asciende con tres puntos. Cámara hacia la clasificación y regreso hacia Exportar. | Voz: clasificación clara. Whoosh 39,30 y tick 43,15. |
| 46–50 | Listo para compartir | Exportar Tabla General cambia de Post a Historia 9:16. La imagen recompone su proporción; pulsación de Descargar acompañada por la cámara. | Voz sobre la imagen para compartir. Clicks 47,00 y 48,85. |
| 50–54,3 | Consulta pública | Se habilita Publico, se copia Link y se abre la tabla pública, como destino distinto de la descarga. | Voz sobre el enlace público. Clicks 50,75 y 51,65; transición 52,30. |
| 54,05–56,7 | **A LA ALTURA / DE TU PASIÓN.** | La interfaz se retira y la cancha queda libre. Tipografía cinética en dos líneas grandes. | Voz desde 52,15: «Organiza tu liga a la altura de su pasión». Riser desde 55,40. |
| 56,65–60 | **Bracket · Más allá del amateur** | Revelado vertical del archivo oficial íntegro, escala uniforme, arco exterior y acercamiento suave. Logo y eslogan se sostienen hasta el final. | Voz de marca 56,90; impacto 57,25 y cierre musical. |

## Locución y mezcla

Narrador sintético español de catálogo `em_alex`, generado localmente con Kokoro-82M; no se clona una identidad real. Texto exacto en `assets/voice/narration-script.txt`, clips y duraciones en `assets/voice/narration-timing.json`. No se añade una URL u oferta no confirmada.

Música: «Techno Fights», Alejandro Magaña (A. M.), Mixkit #171. Se detectaron 122,3 BPM y se corrigió la cuadrícula por +108 ms al contrastarla con los graves. Offset elegido: 2,160 s; errores de los dos grandes revelados: 67 ms y 15 ms. La cama baja 10 dB durante la voz, con anticipación de 120 ms y recuperación de 300 ms. Un solo efecto por cue; clicks repetidos atenuados.

## Fidelidad

Se verificaron configuración, participantes, fixture, jornadas, resultados, escaneo con revisión, clasificación, exportación y consulta pública. No se promociona la ruta `/partidos`, marcada «Próximamente». Filas, enlaces de datos y cámara son recursos editoriales; no prometen esas mismas animaciones dentro de la app ni una velocidad de lectura medida.

Equipos, cédula y resultados son ficticios. El 2–1 y el empate Norte–Sur producen puntos 3, 1, 1 y 0, contrastados con el cálculo de Bracket. Se conserva revisión → aplicar → guardar → confirmar. No se representa publicación automática en redes.
