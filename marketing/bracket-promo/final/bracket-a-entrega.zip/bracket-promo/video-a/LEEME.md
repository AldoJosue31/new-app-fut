# Bracket — VIDEO A

Revisión inmersiva con narrador · «Más allá del amateur» · 60 s · 1080 × 1920 · 60 FPS.

## Preview y edición

`index.html` contiene las fuentes Poppins y el logo original incrustados. Mantener la estructura del paquete: el audio se reproduce desde `../final/bracket-a-60s.mp4`. Abrir desde `node video-a/serve.mjs` en la raíz de campaña y visitar `http://127.0.0.1:4188/video-a/index.html`. Play, pausa y scrub funcionan sin regenerar el render. `?captions` muestra subtítulos de apoyo; no están quemados en el master.

Editar `ui-scenes.js` para los controles reconstruidos, `immersive.js` para cámara, perspectiva, capítulos y cierre. Ejecutar `node video-a/build.mjs` para reconstruir el HTML. `template.html` contiene los controles del preview. `beat-sheet.json`, `cues.json` y `narration-plan.json` describen los tiempos; `../03-video-a-storyboard.md` desarrolla la intención publicitaria.

El motor expone `window.VIDEO` y `window.seek(t)` como función de tiempo. Sin historial de frames, timers o transiciones CSS en la composición. Se puede buscar cualquier fotograma en cualquier orden. Las entradas usan una malla en perspectiva; durante la lectura los paneles vuelven a una posición frontal.

## Render

Requisitos: Node, Playwright/Chromium y FFmpeg. En una copia independiente ejecutar `npm install` y `npx playwright install chromium` desde `video-a/`. FFmpeg debe estar en PATH o indicarse mediante `FFMPEG_PATH`. No modificar dependencias de la aplicación.

Desde la raíz de la campaña:

```text
node video-a/build.mjs
node video-a/render.mjs video-a/index.html review/a-check.png --stills 1,8.6,18.7,33.9,44,58.5
node video-a/render.mjs video-a/index.html review/a-draft.mp4 30 1 4
node video-a/render.mjs video-a/index.html final/bracket-a-60s.mp4 60 4 4
```

El render escribe `*_silent.mp4`; la mezcla se añade después. Se conserva el renderer de `explainer-default`, adaptado a Windows y captura Canvas JPEG 95, con cuatro subfotogramas por frame y obturador de 180°. La captura PNG se contrastó con la del navegador y se comprobó acceso aleatorio determinista. No ejecutar los antiguos ayudantes de migración sobre esta versión.

## Narración

Los clips entregados permiten rehacer la mezcla sin descargar un modelo. Para regenerarlos, instalar `../sound-a/requirements.txt` en un entorno Python 3.11 local, descargar los archivos oficiales `kokoro-v1.0.onnx` y `voices-v1.0.bin` de `https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.1` en `../.models/` y leer su licencia. Ejecutar:

```text
python video-a/generate-voice.py
ffmpeg -y -i assets/voice/narration-timeline.wav -af highpass=f=75,lowpass=f=10000,acompressor=threshold=0.16:ratio=2.5:attack=8:release=120:makeup=1.15,loudnorm=I=-17:TP=-7:LRA=7 -ar 48000 -ac 2 assets/voice/narration-clean.wav
node video-a/export-narration.mjs
```

`em_alex` es una voz sintética española de catálogo. El texto usa «Bráquet» únicamente en la entrada fonética del sintetizador; la marca visible y el guion mantienen Bracket. Los subtítulos son segmentados por frases con tiempos aproximados.

## Música y efectos

Leer `../assets/licenses/LICENCE-REVIEW.md`. Los originales Mixkit no acompañan el paquete de fuentes. `node video-a/download-audio.mjs` descarga localmente Techno Fights #171 y teclado #1392 desde su fuente; comprobar los términos vigentes antes de reutilizarlos.

Ejecutar con FFmpeg en PATH, desde la raíz de la campaña:

```text
python sound-a/scripts/sound_pass.py --video final/bracket-a-60s_silent.mp4 --cues video-a/cues.json --music assets/audio/mixkit-171-techno-fights.mp3 --manifest sound-a/scripts/manifest.json --out sound-a --music-db -7 --sfx-db -5 --voiceover assets/voice/narration-clean.wav --voice-timing assets/voice/narration-timing.json --music-source "Techno Fights, Alejandro Magana (A. M.), Mixkit 171, https://mixkit.co/free-stock-music/electronica/" --music-license "Mixkit Stock Music Free License" --use-case "Instagram, TikTok, online advertising"
```

La música se alinea con los revelados y baja 10 dB bajo la voz. `sound-a/after.mp4` contiene la mezcla medida; copiarla al master con faststart sin recodificar el video. Objetivo: −16 LUFS aproximadamente y pico real menor que −4 dBFS en estéreo y mono. `SOUND.md`, `beatgrid.png`, `checks/`, `report.html` y `CREDITS.txt` documentan los resultados. Los créditos son opcionales para descripciones de redes y conservan la procedencia.

## Alcance

Interfaz fiel recreada y simplificada por encuadre, datos ficticios y tiempos resumidos. El escaneo mantiene revisión → aplicar → guardar → confirmar y lleva un aviso ilustrativo. No es una lectura remota real ni una medición de velocidad. La exportación y la consulta pública son salidas diferentes. Consultar `../ASSETS.md` y `../QA.md`.
