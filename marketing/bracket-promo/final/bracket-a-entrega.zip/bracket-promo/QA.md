# VIDEO A — control de calidad

Revisión inmersiva solicitada por el usuario, con narrador. Solo A está producido; B y C conservan el estado de propuesta.

## Archivo entregado

| Comprobación del MP4 final | Resultado |
|---|---|
| Duración | 60,000 s |
| Resolución y proporción | 1080 × 1920 · 9:16 |
| Frecuencia y fotogramas | 60 FPS constantes · 3.600 frames |
| Video | H.264 · yuv420p · MP4 con faststart |
| Audio | AAC estéreo |
| Versión silenciosa | Un stream de video, sin audio |
| Decodificación completa | Sin errores de FFmpeg |
| Sonoridad estéreo / mono | −16,3 / −16,3 LUFS integrados |
| Pico real estéreo / mono | −5,1 / −5,1 dBFS |

Mediciones realizadas sobre `final/bracket-a-60s.mp4`, después del remux de distribución. Datos completos, streams y resúmenes ebur128 en [technical-qa.json](final/technical-qa.json). La música, voz y efectos se mezclaron una sola vez sobre el master silencioso.

## Imagen y animación

- Revisada la [hoja extraída del master](review/a-master-contact-sheet.jpg) en 18 tiempos, además de las hojas del HTML y pruebas de los cues.
- Interacciones animadas: escritura, campos, incorporación de equipos, fixture, hora, lista/grilla, confirmación de jornada, lectura ilustrativa, revisión y guardado de resultado, orden de tabla, exportación y enlace público.
- Cámara y perspectiva durante entradas/salidas; paneles frontales durante lectura. Los recortes de navegación y bordes son encuadres editoriales; los controles protagonistas se muestran al actuar sobre ellos.
- Los títulos de capítulo, la revisión de cédula y el cierre se mantienen en zonas distintas; no se superponen entre sí en las muestras revisadas.
- Poppins 400, 600 y 700 cargadas desde fuentes incrustadas. No se detectó fallback.
- Acceso aleatorio determinista comprobado. Captura PNG del lienzo y captura del navegador idénticas: [resultados](review/composition-checks.json), [comparación](review/capture-equivalence.json).
- Render de `explainer-default` con cuatro muestras temporales por frame, media exposición y combinación temporal de motion blur. La dirección oscura y el narrador responden al cambio explícito del usuario respecto al primer borrador.

## Identidad y fidelidad al producto

Logo copiado byte a byte desde `public/logo_app.png`. SHA-256: `8fdfd91bbc70c43ce0b3fd13683c8ec5563a913d4c70e5bb411620b776179217`. Se anima mediante escala uniforme y máscara; se conservan proporciones, geometría y colores. Paleta y tipografías proceden de Bracket.

La implementación se investigó antes de producir el video. El módulo operativo es Torneos → Jornadas; no se incluye la ruta independiente Partidos, todavía «Próximamente». Se conservan revisión, aplicación y confirmación de la cédula. No se invocó el proveedor remoto ni se mide o promete su velocidad. El aviso ilustrativo aparece durante esa secuencia.

Competición, equipos y resultados ficticios. Tabla coherente con el cálculo real: Halcones 3, Norte 1, Sur 1, Leones 0. Descargar una imagen y habilitar una tabla pública son salidas distintas. No se añadieron testimonios, precios, oferta gratuita o métricas comerciales. No se modificó código funcional de la app; el estado Git solo añade la carpeta de marketing.

## Sonido y licencias

Voz sintética española de catálogo `em_alex`, generada localmente con Kokoro-82M. No se clona una persona real. Texto y duraciones en `assets/voice/`; SRT opcional segmentado por frases con tiempos aproximados. No está quemado en el master. El HTML puede mostrarlo mediante `?captions`.

Música: «Techno Fights», Alejandro Magaña (A. M.), Mixkit #171. Efectos grabados del kit CC0 y teclado Mixkit #1392. Prioridad voz → efectos → música; ducking de 10 dB durante locución, anticipación 120 ms y recuperación 300 ms. No se sintetiza música ni SFX.

Cuadrícula musical contrastada con graves <120 Hz: 122,283 BPM, corregida +108 ms. Offset 2,160 s. Error respecto al beat en la presentación de marca: 67 ms; en el cierre: 15 ms. [Gráfico de comprobación](sound-a/beatgrid.png), [análisis numérico](sound-a/music-analysis.json), [informe completo](sound-a/SOUND.md) y [reporte HTML](sound-a/report.html). Se generaron frames antes/después y formas de onda para los 30 cues, con el master de 60 FPS.

Comprobadas durante esta producción: Mixkit Stock Music Free License y SFX Free License, compatibles con redes y anuncios online; las seis páginas Freesound indican CC0; Kokoro declara Apache 2.0. Enlaces de origen en [LICENCE-REVIEW.md](assets/licenses/LICENCE-REVIEW.md). Los originales Mixkit permanecen locales y se excluyen del ZIP; el MP4 sincronizado sí se entrega. Fuentes y condiciones pueden cambiar. [CREDITS.txt](sound-a/CREDITS.txt) es opcional para una descripción y conserva la procedencia. El procedimiento sound-effects acredita a Vox / @Voxyz_ai.

## Cinco puntos de escucha con auriculares

Las mediciones comprueban niveles y sincronía; no sustituyen una valoración auditiva humana.

| Tiempo | Comprobar |
|---|---|
| 0,40 s | Whoosh de apertura respecto a la primera frase |
| 4,65 s | Presentación de marca y entrada de la locución Bracket |
| 7,55 s | Teclado bajo la explicación del torneo |
| 55,40 s | Riser durante la salida hacia el cierre |
| 57,25 s | Impacto, logo completo y eslogan narrado |

## Entrega y reproducción

El ZIP incorpora master, versión sin audio, poster, SRT, HTML, archivos de animación, voz generada, gráficos originales, fuentes, efectos CC0, guion, investigación e informes. Excluye pesos del modelo, entornos, binarios, archivos Mixkit aislados y versiones descartadas. `DELIVERY-MANIFEST.json` dentro del ZIP registra tamaño y SHA-256 de cada archivo.

El HTML reproduce el audio desde el master entregado. Mantener las carpetas juntas y utilizar el servidor local incluido. La escucha humana de los cinco puntos se deja identificada para la revisión editorial del usuario; no se afirma una calidad auditiva subjetiva comprobada.
