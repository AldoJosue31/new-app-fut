# Recursos sonoros — verificación para el video A

Revisión realizada el 6 de noviembre de 2026, America/Mexico_City. Uso previsto: publicaciones de Instagram/TikTok y anuncios online. Las fuentes se comprobaron durante esta producción; no se utilizó una cuenta del usuario para adquirir recursos.

## Mixkit

Se abrió la [licencia oficial](https://mixkit.co/license/) en Chromium, incluidos los desplegables de música y efectos. Ambos autorizan el uso comercial en publicaciones de redes sociales y anuncios de marketing online. La pista elegida también aparece en el [catálogo oficial](https://mixkit.co/free-stock-music/electronica/).

- Música de la revisión inmersiva: «Techno Fights», Alejandro Magaña (A. M.), Mixkit #171. Offset de 2,160 s registrado en `sound-a/SOUND.md`. La pista #834 pertenece al borrador anterior y no se utiliza en el master final.
- Escritura: «Fast laptop keyboard typing», Mixkit #1392, [catálogo de escritura](https://mixkit.co/free-sound-effects/typing/).
- Los originales descargados se mantienen en la carpeta de trabajo y se excluyen del paquete de fuentes. Los efectos Mixkit no se redistribuyen como archivos de biblioteca ni junto al código fuente.
- El MP4 sincronizado es el producto final de esta campaña. La música no se ofrece como pista independiente ni se registra en un sistema de gestión de derechos.

## Freesound / CC0

Se comprobó que las siguientes páginas identifican los recursos como Creative Commons 0 y permiten uso comercial. Se utiliza el kit grabado que incluye la skill; los archivos CC0 pueden acompañar las fuentes.

| Recurso | Autor | Página comprobada |
|---|---|---|
| Whoosh | qubodup | [60013](https://freesound.org/people/qubodup/sounds/60013/) |
| Classic Click | adh.dreaming | [671105](https://freesound.org/people/adh.dreaming/sounds/671105/) |
| POP SFX Neutral | ethernel0 | [776016](https://freesound.org/people/ethernel0/sounds/776016/) |
| Cinematic Riser #3 subtle | BeaconStudio | [859482](https://freesound.org/people/BeaconStudio/sounds/859482/) |
| soft_impact3 | peoplearehappy | [841274](https://freesound.org/people/peoplearehappy/sounds/841274/) |
| Click / Tick | Squirrel_404 | [683048](https://freesound.org/people/Squirrel_404/sounds/683048/) |

Los créditos de los sonidos efectivamente colocados se generan en `sound-a/CREDITS.txt`. El procedimiento de análisis y mezcla se basa en `sound-effects`, que acredita el sound pass de Vox / @Voxyz_ai.

## Narrador

El [model card oficial de Kokoro-82M](https://huggingface.co/hexgrad/Kokoro-82M) identifica el modelo como Apache 2.0 y permite uso en producción comercial. Voz española de catálogo `em_alex`, identificada en el [listado oficial](https://huggingface.co/hexgrad/Kokoro-82M/blob/main/VOICES.md). No se clona una persona real. Texto Apache 2.0 en `Kokoro-APACHE-2.0.txt`; pesos excluidos del paquete. El ejecutor [kokoro-onnx](https://github.com/thewh1teagle/kokoro-onnx) utiliza MIT.
